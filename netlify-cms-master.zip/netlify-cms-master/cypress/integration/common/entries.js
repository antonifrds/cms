export const entry1 = {
  title: 'first title',
  body: 'first body',
  description: 'first description',
  category: 'first category',
  tags: 'tag1',
};
export const entry2 = {
  title: 'second title',
  body: 'second body',
  description: 'second description',
  category: 'second category',
  tags: 'tag2',
};
export const entry3 = {
  title: 'third title',
  body: 'third body',
  description: 'third description',
  category: 'third category',
  tags: 'tag3',
};
