# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.15.72](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.71...netlify-cms-app@2.15.72) (2022-04-13)

**Note:** Version bump only for package netlify-cms-app





## [2.15.71](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.70...netlify-cms-app@2.15.71) (2022-04-13)

**Note:** Version bump only for package netlify-cms-app





## [2.15.70](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.69...netlify-cms-app@2.15.70) (2022-03-28)

**Note:** Version bump only for package netlify-cms-app





## [2.15.69](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.68...netlify-cms-app@2.15.69) (2022-03-14)

**Note:** Version bump only for package netlify-cms-app





## [2.15.68](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.67...netlify-cms-app@2.15.68) (2022-03-08)

**Note:** Version bump only for package netlify-cms-app





## [2.15.67](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.66...netlify-cms-app@2.15.67) (2022-02-28)

**Note:** Version bump only for package netlify-cms-app





## [2.15.66](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.65...netlify-cms-app@2.15.66) (2022-02-08)

**Note:** Version bump only for package netlify-cms-app





## [2.15.65](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.64...netlify-cms-app@2.15.65) (2022-01-21)

**Note:** Version bump only for package netlify-cms-app





## [2.15.64](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.63...netlify-cms-app@2.15.64) (2022-01-21)

**Note:** Version bump only for package netlify-cms-app





## [2.15.63](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.62...netlify-cms-app@2.15.63) (2021-12-28)

**Note:** Version bump only for package netlify-cms-app





## [2.15.62](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.61...netlify-cms-app@2.15.62) (2021-12-21)

**Note:** Version bump only for package netlify-cms-app





## [2.15.61](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.60...netlify-cms-app@2.15.61) (2021-12-08)

**Note:** Version bump only for package netlify-cms-app





## [2.15.60](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.59...netlify-cms-app@2.15.60) (2021-12-03)

**Note:** Version bump only for package netlify-cms-app





## [2.15.59](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.58...netlify-cms-app@2.15.59) (2021-11-12)

**Note:** Version bump only for package netlify-cms-app





## [2.15.58](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.57...netlify-cms-app@2.15.58) (2021-11-01)

**Note:** Version bump only for package netlify-cms-app





## [2.15.57](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.56...netlify-cms-app@2.15.57) (2021-10-28)

**Note:** Version bump only for package netlify-cms-app





## [2.15.56](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.55...netlify-cms-app@2.15.56) (2021-10-28)

**Note:** Version bump only for package netlify-cms-app





## [2.15.55](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.54...netlify-cms-app@2.15.55) (2021-10-25)

**Note:** Version bump only for package netlify-cms-app





## [2.15.54](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.53...netlify-cms-app@2.15.54) (2021-10-21)

**Note:** Version bump only for package netlify-cms-app





## [2.15.53](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.52...netlify-cms-app@2.15.53) (2021-10-18)

**Note:** Version bump only for package netlify-cms-app





## [2.15.52](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.51...netlify-cms-app@2.15.52) (2021-10-15)

**Note:** Version bump only for package netlify-cms-app





## [2.15.51](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.50...netlify-cms-app@2.15.51) (2021-10-11)

**Note:** Version bump only for package netlify-cms-app





## [2.15.50](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.49...netlify-cms-app@2.15.50) (2021-10-11)

**Note:** Version bump only for package netlify-cms-app





## [2.15.49](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.48...netlify-cms-app@2.15.49) (2021-10-08)

**Note:** Version bump only for package netlify-cms-app





## [2.15.48](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.47...netlify-cms-app@2.15.48) (2021-10-07)

**Note:** Version bump only for package netlify-cms-app





## [2.15.47](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.46...netlify-cms-app@2.15.47) (2021-10-07)

**Note:** Version bump only for package netlify-cms-app





## [2.15.46](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.45...netlify-cms-app@2.15.46) (2021-09-30)

**Note:** Version bump only for package netlify-cms-app





## [2.15.45](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.44...netlify-cms-app@2.15.45) (2021-09-29)

**Note:** Version bump only for package netlify-cms-app





## [2.15.44](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.43...netlify-cms-app@2.15.44) (2021-09-13)

**Note:** Version bump only for package netlify-cms-app





## [2.15.43](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.42...netlify-cms-app@2.15.43) (2021-09-13)

**Note:** Version bump only for package netlify-cms-app





## [2.15.42](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.41...netlify-cms-app@2.15.42) (2021-09-13)

**Note:** Version bump only for package netlify-cms-app





## [2.15.41](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.40...netlify-cms-app@2.15.41) (2021-09-10)

**Note:** Version bump only for package netlify-cms-app





## [2.15.40](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.39...netlify-cms-app@2.15.40) (2021-08-30)

**Note:** Version bump only for package netlify-cms-app





## [2.15.39](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.38...netlify-cms-app@2.15.39) (2021-08-24)

**Note:** Version bump only for package netlify-cms-app





## [2.15.38](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.37...netlify-cms-app@2.15.38) (2021-08-17)

**Note:** Version bump only for package netlify-cms-app





## [2.15.37](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.36...netlify-cms-app@2.15.37) (2021-08-17)

**Note:** Version bump only for package netlify-cms-app





## [2.15.36](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.35...netlify-cms-app@2.15.36) (2021-08-11)

**Note:** Version bump only for package netlify-cms-app





## [2.15.35](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.34...netlify-cms-app@2.15.35) (2021-08-10)

**Note:** Version bump only for package netlify-cms-app





## [2.15.34](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.33...netlify-cms-app@2.15.34) (2021-08-09)

**Note:** Version bump only for package netlify-cms-app





## [2.15.33](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.32...netlify-cms-app@2.15.33) (2021-08-04)

**Note:** Version bump only for package netlify-cms-app





## [2.15.32](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.31...netlify-cms-app@2.15.32) (2021-08-04)

**Note:** Version bump only for package netlify-cms-app





## [2.15.31](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.30...netlify-cms-app@2.15.31) (2021-08-03)

**Note:** Version bump only for package netlify-cms-app





## [2.15.30](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.29...netlify-cms-app@2.15.30) (2021-07-25)

**Note:** Version bump only for package netlify-cms-app





## [2.15.29](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.28...netlify-cms-app@2.15.29) (2021-07-25)

**Note:** Version bump only for package netlify-cms-app





## [2.15.28](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.27...netlify-cms-app@2.15.28) (2021-07-20)

**Note:** Version bump only for package netlify-cms-app





## [2.15.27](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.26...netlify-cms-app@2.15.27) (2021-07-14)

**Note:** Version bump only for package netlify-cms-app





## [2.15.26](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.25...netlify-cms-app@2.15.26) (2021-07-07)

**Note:** Version bump only for package netlify-cms-app





## [2.15.25](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.24...netlify-cms-app@2.15.25) (2021-07-07)

**Note:** Version bump only for package netlify-cms-app





## [2.15.24](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.23...netlify-cms-app@2.15.24) (2021-07-07)

**Note:** Version bump only for package netlify-cms-app





## [2.15.23](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.22...netlify-cms-app@2.15.23) (2021-07-06)

**Note:** Version bump only for package netlify-cms-app





## [2.15.22](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.21...netlify-cms-app@2.15.22) (2021-07-06)

**Note:** Version bump only for package netlify-cms-app





## [2.15.21](https://github.com/netlify/netlify-cms/compare/netlify-cms-app@2.15.20...netlify-cms-app@2.15.21) (2021-07-05)

**Note:** Version bump only for package netlify-cms-app





## [2.15.20](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.19...netlify-cms-app@2.15.20) (2021-06-24)

**Note:** Version bump only for package netlify-cms-app





## [2.15.19](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.18...netlify-cms-app@2.15.19) (2021-06-10)

**Note:** Version bump only for package netlify-cms-app





## [2.15.18](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.17...netlify-cms-app@2.15.18) (2021-06-07)

**Note:** Version bump only for package netlify-cms-app





## [2.15.17](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.16...netlify-cms-app@2.15.17) (2021-06-01)

**Note:** Version bump only for package netlify-cms-app





## [2.15.16](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.15...netlify-cms-app@2.15.16) (2021-05-31)

**Note:** Version bump only for package netlify-cms-app





## [2.15.15](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.14...netlify-cms-app@2.15.15) (2021-05-30)

**Note:** Version bump only for package netlify-cms-app





## [2.15.14](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.13...netlify-cms-app@2.15.14) (2021-05-30)

**Note:** Version bump only for package netlify-cms-app





## [2.15.13](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.12...netlify-cms-app@2.15.13) (2021-05-30)

**Note:** Version bump only for package netlify-cms-app





## [2.15.12](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.11...netlify-cms-app@2.15.12) (2021-05-30)

**Note:** Version bump only for package netlify-cms-app





## [2.15.11](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.10...netlify-cms-app@2.15.11) (2021-05-23)

**Note:** Version bump only for package netlify-cms-app





## [2.15.10](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.9...netlify-cms-app@2.15.10) (2021-05-23)

**Note:** Version bump only for package netlify-cms-app





## [2.15.9](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.8...netlify-cms-app@2.15.9) (2021-05-19)

**Note:** Version bump only for package netlify-cms-app





## [2.15.8](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.7...netlify-cms-app@2.15.8) (2021-05-19)

**Note:** Version bump only for package netlify-cms-app





## [2.15.7](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.6...netlify-cms-app@2.15.7) (2021-05-19)

**Note:** Version bump only for package netlify-cms-app





## [2.15.6](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.5...netlify-cms-app@2.15.6) (2021-05-12)

**Note:** Version bump only for package netlify-cms-app





## [2.15.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.4...netlify-cms-app@2.15.5) (2021-05-12)

**Note:** Version bump only for package netlify-cms-app





## [2.15.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.3...netlify-cms-app@2.15.4) (2021-05-10)

**Note:** Version bump only for package netlify-cms-app





## [2.15.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.2...netlify-cms-app@2.15.3) (2021-05-09)

**Note:** Version bump only for package netlify-cms-app





## [2.15.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.1...netlify-cms-app@2.15.2) (2021-05-04)

**Note:** Version bump only for package netlify-cms-app





## [2.15.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.15.0...netlify-cms-app@2.15.1) (2021-05-04)

**Note:** Version bump only for package netlify-cms-app





# [2.15.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.48...netlify-cms-app@2.15.0) (2021-05-04)


### Features

* added react 17 as peer dependency in packages ([#5316](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/5316)) ([9e42380](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/9e423805707321396eec137f5b732a5b07a0dd3f))





## [2.14.48](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.47...netlify-cms-app@2.14.48) (2021-05-03)

**Note:** Version bump only for package netlify-cms-app





## [2.14.47](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.46...netlify-cms-app@2.14.47) (2021-04-29)

**Note:** Version bump only for package netlify-cms-app





## [2.14.46](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.45...netlify-cms-app@2.14.46) (2021-04-18)

**Note:** Version bump only for package netlify-cms-app





## [2.14.45](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.44...netlify-cms-app@2.14.45) (2021-04-14)


### Bug Fixes

* Revert "fix: generate esm correctly ([#5087](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/5087))" ([#5271](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/5271)) ([72c3765](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/72c3765ff7e04a1dadc77f49b53a2e2da0181026))





## [2.14.44](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.43...netlify-cms-app@2.14.44) (2021-04-14)

**Note:** Version bump only for package netlify-cms-app





## [2.14.43](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.42...netlify-cms-app@2.14.43) (2021-04-13)


### Bug Fixes

* add missing code codemirror deps ([#5267](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/5267)) ([0aa7766](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/0aa7766ad6584961e09805825d46551aebfab6a2))





## [2.14.42](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.41...netlify-cms-app@2.14.42) (2021-04-13)


### Bug Fixes

* add missing dependencies ([#5265](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/5265)) ([1e12e20](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/1e12e208d4a797dff2031d8b52369cf14a39cfeb))





## [2.14.41](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.40...netlify-cms-app@2.14.41) (2021-04-13)

**Note:** Version bump only for package netlify-cms-app





## [2.14.40](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.39...netlify-cms-app@2.14.40) (2021-04-07)

**Note:** Version bump only for package netlify-cms-app





## [2.14.39](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.38...netlify-cms-app@2.14.39) (2021-04-07)

**Note:** Version bump only for package netlify-cms-app





## [2.14.38](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.37...netlify-cms-app@2.14.38) (2021-04-06)

**Note:** Version bump only for package netlify-cms-app





## [2.14.37](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.36...netlify-cms-app@2.14.37) (2021-04-04)

**Note:** Version bump only for package netlify-cms-app





## [2.14.36](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.35...netlify-cms-app@2.14.36) (2021-04-04)


### Bug Fixes

* generate esm correctly ([#5087](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/5087)) ([9b1546f](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/9b1546f131772185b3d39d18b6e57dc41ff5c7ca))





## [2.14.35](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.34...netlify-cms-app@2.14.35) (2021-04-01)

**Note:** Version bump only for package netlify-cms-app





## [2.14.34](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.33...netlify-cms-app@2.14.34) (2021-03-31)

**Note:** Version bump only for package netlify-cms-app





## [2.14.33](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.32...netlify-cms-app@2.14.33) (2021-03-30)

**Note:** Version bump only for package netlify-cms-app





## [2.14.32](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.31...netlify-cms-app@2.14.32) (2021-03-21)

**Note:** Version bump only for package netlify-cms-app





## [2.14.31](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.30...netlify-cms-app@2.14.31) (2021-03-21)

**Note:** Version bump only for package netlify-cms-app





## [2.14.30](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.29...netlify-cms-app@2.14.30) (2021-03-18)

**Note:** Version bump only for package netlify-cms-app





## [2.14.29](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.28...netlify-cms-app@2.14.29) (2021-03-11)

**Note:** Version bump only for package netlify-cms-app





## [2.14.28](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.27...netlify-cms-app@2.14.28) (2021-03-11)

**Note:** Version bump only for package netlify-cms-app





## [2.14.27](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.26...netlify-cms-app@2.14.27) (2021-03-10)

**Note:** Version bump only for package netlify-cms-app





## [2.14.26](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.25...netlify-cms-app@2.14.26) (2021-02-25)

**Note:** Version bump only for package netlify-cms-app





## [2.14.25](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.24...netlify-cms-app@2.14.25) (2021-02-23)

**Note:** Version bump only for package netlify-cms-app





## [2.14.24](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.23...netlify-cms-app@2.14.24) (2021-02-22)

**Note:** Version bump only for package netlify-cms-app





## [2.14.23](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.22...netlify-cms-app@2.14.23) (2021-02-16)

**Note:** Version bump only for package netlify-cms-app





## [2.14.22](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.21...netlify-cms-app@2.14.22) (2021-02-15)

**Note:** Version bump only for package netlify-cms-app





## [2.14.21](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.20...netlify-cms-app@2.14.21) (2021-02-10)

**Note:** Version bump only for package netlify-cms-app





## [2.14.20](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.19...netlify-cms-app@2.14.20) (2021-02-07)

**Note:** Version bump only for package netlify-cms-app





## [2.14.19](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.18...netlify-cms-app@2.14.19) (2021-02-07)

**Note:** Version bump only for package netlify-cms-app





## [2.14.18](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.17...netlify-cms-app@2.14.18) (2021-02-03)

**Note:** Version bump only for package netlify-cms-app





## [2.14.17](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.16...netlify-cms-app@2.14.17) (2021-02-01)

**Note:** Version bump only for package netlify-cms-app





## [2.14.16](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.15...netlify-cms-app@2.14.16) (2021-02-01)

**Note:** Version bump only for package netlify-cms-app





## [2.14.15](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.14...netlify-cms-app@2.14.15) (2021-02-01)

**Note:** Version bump only for package netlify-cms-app





## [2.14.14](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.13...netlify-cms-app@2.14.14) (2021-01-19)

**Note:** Version bump only for package netlify-cms-app





## [2.14.13](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.12...netlify-cms-app@2.14.13) (2021-01-19)

**Note:** Version bump only for package netlify-cms-app





## [2.14.12](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.11...netlify-cms-app@2.14.12) (2021-01-14)

**Note:** Version bump only for package netlify-cms-app





## [2.14.11](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.10...netlify-cms-app@2.14.11) (2021-01-12)

**Note:** Version bump only for package netlify-cms-app





## [2.14.10](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.9...netlify-cms-app@2.14.10) (2021-01-05)

**Note:** Version bump only for package netlify-cms-app





## [2.14.9](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.8...netlify-cms-app@2.14.9) (2021-01-04)

**Note:** Version bump only for package netlify-cms-app





## [2.14.8](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.7...netlify-cms-app@2.14.8) (2020-12-23)

**Note:** Version bump only for package netlify-cms-app





## [2.14.7](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.6...netlify-cms-app@2.14.7) (2020-12-20)

**Note:** Version bump only for package netlify-cms-app





## [2.14.6](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.5...netlify-cms-app@2.14.6) (2020-12-15)

**Note:** Version bump only for package netlify-cms-app





## [2.14.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.4...netlify-cms-app@2.14.5) (2020-12-13)

**Note:** Version bump only for package netlify-cms-app





## [2.14.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.3...netlify-cms-app@2.14.4) (2020-12-06)

**Note:** Version bump only for package netlify-cms-app





## [2.14.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.2...netlify-cms-app@2.14.3) (2020-11-30)

**Note:** Version bump only for package netlify-cms-app





## [2.14.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.1...netlify-cms-app@2.14.2) (2020-11-30)

**Note:** Version bump only for package netlify-cms-app





## [2.14.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.14.0...netlify-cms-app@2.14.1) (2020-11-26)

**Note:** Version bump only for package netlify-cms-app





# [2.14.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.13.4...netlify-cms-app@2.14.0) (2020-11-26)


### Features

* add azure devops backend ([#4427](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/4427)) ([4e6dc88](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/4e6dc88efb1dae4cf6137730c3b4fb6d0f75a8cc))





## [2.13.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.13.3...netlify-cms-app@2.13.4) (2020-11-26)

**Note:** Version bump only for package netlify-cms-app





## [2.13.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.13.2...netlify-cms-app@2.13.3) (2020-11-08)

**Note:** Version bump only for package netlify-cms-app





## [2.13.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.13.1...netlify-cms-app@2.13.2) (2020-11-02)

**Note:** Version bump only for package netlify-cms-app





## [2.13.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.13.0...netlify-cms-app@2.13.1) (2020-10-26)


### Bug Fixes

* **deps:** update color widget dependecy ([#4512](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/4512)) ([a0176e4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/a0176e457223da65dddf983707704dd4441553a0))





# [2.13.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.28...netlify-cms-app@2.13.0) (2020-10-25)


### Bug Fixes

* **widget-color:** rename to colorstring ([#4496](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/4496)) ([fbc8963](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/fbc89637267f65ede25cd15ff6ed832ab3eb44dc))


### Features

* **widget-color:** add color widget ([#4437](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/4437)) ([fed0e82](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/fed0e82dd3d35c611b0ef58d2008d299f94102d9))





## [2.12.28](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.27...netlify-cms-app@2.12.28) (2020-10-20)

**Note:** Version bump only for package netlify-cms-app





## [2.12.27](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.26...netlify-cms-app@2.12.27) (2020-10-12)

**Note:** Version bump only for package netlify-cms-app





## [2.12.26](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.25...netlify-cms-app@2.12.26) (2020-10-12)

**Note:** Version bump only for package netlify-cms-app





## [2.12.25](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.24...netlify-cms-app@2.12.25) (2020-09-28)

**Note:** Version bump only for package netlify-cms-app





## [2.12.24](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.23...netlify-cms-app@2.12.24) (2020-09-20)

**Note:** Version bump only for package netlify-cms-app





## [2.12.23](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.22...netlify-cms-app@2.12.23) (2020-09-20)

**Note:** Version bump only for package netlify-cms-app





## [2.12.22](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.21...netlify-cms-app@2.12.22) (2020-09-15)

**Note:** Version bump only for package netlify-cms-app





## 2.12.21 (2020-09-08)


### Reverts

* Revert "chore(release): publish" ([828bb16](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/828bb16415b8c22a34caa19c50c38b24ffe9ceae))





## 2.12.20 (2020-08-20)


### Reverts

* Revert "chore(release): publish" ([8262487](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/82624879ccbcb16610090041db28f00714d924c8))





## 2.12.19 (2020-07-27)


### Reverts

* Revert "chore(release): publish" ([118d50a](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/118d50a7a70295f25073e564b5161aa2b9883056))





## [2.12.18](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.17...netlify-cms-app@2.12.18) (2020-07-16)

**Note:** Version bump only for package netlify-cms-app





## [2.12.17](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.16...netlify-cms-app@2.12.17) (2020-07-14)

**Note:** Version bump only for package netlify-cms-app





## [2.12.16](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.15...netlify-cms-app@2.12.16) (2020-07-01)

**Note:** Version bump only for package netlify-cms-app





## [2.12.15](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.14...netlify-cms-app@2.12.15) (2020-06-18)

**Note:** Version bump only for package netlify-cms-app





## [2.12.14](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.13...netlify-cms-app@2.12.14) (2020-06-01)

**Note:** Version bump only for package netlify-cms-app





## [2.12.13](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.12...netlify-cms-app@2.12.13) (2020-05-19)

**Note:** Version bump only for package netlify-cms-app





## [2.12.12](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.11...netlify-cms-app@2.12.12) (2020-05-04)

**Note:** Version bump only for package netlify-cms-app





## [2.12.11](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.10...netlify-cms-app@2.12.11) (2020-04-21)

**Note:** Version bump only for package netlify-cms-app





## [2.12.10](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.9...netlify-cms-app@2.12.10) (2020-04-20)

**Note:** Version bump only for package netlify-cms-app





## [2.12.9](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.8...netlify-cms-app@2.12.9) (2020-04-16)

**Note:** Version bump only for package netlify-cms-app





## [2.12.8](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.7...netlify-cms-app@2.12.8) (2020-04-14)

**Note:** Version bump only for package netlify-cms-app





## [2.12.7](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.6...netlify-cms-app@2.12.7) (2020-04-10)

**Note:** Version bump only for package netlify-cms-app





## [2.12.6](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.5...netlify-cms-app@2.12.6) (2020-04-09)

**Note:** Version bump only for package netlify-cms-app





## [2.12.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.4...netlify-cms-app@2.12.5) (2020-04-07)

**Note:** Version bump only for package netlify-cms-app





## [2.12.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.3...netlify-cms-app@2.12.4) (2020-04-06)

**Note:** Version bump only for package netlify-cms-app





## [2.12.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.2...netlify-cms-app@2.12.3) (2020-04-01)

**Note:** Version bump only for package netlify-cms-app





## [2.12.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.1...netlify-cms-app@2.12.2) (2020-04-01)

**Note:** Version bump only for package netlify-cms-app





## [2.12.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.12.0...netlify-cms-app@2.12.1) (2020-04-01)

**Note:** Version bump only for package netlify-cms-app





# [2.12.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.32...netlify-cms-app@2.12.0) (2020-03-30)


### Features

* expose CMS moment ([#3458](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/3458)) ([cd324b0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/cd324b08f191925f271178a326d65a000167d130))





## [2.11.32](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.31...netlify-cms-app@2.11.32) (2020-03-20)

**Note:** Version bump only for package netlify-cms-app





## [2.11.31](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.30...netlify-cms-app@2.11.31) (2020-03-19)

**Note:** Version bump only for package netlify-cms-app





## [2.11.30](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.29...netlify-cms-app@2.11.30) (2020-03-19)

**Note:** Version bump only for package netlify-cms-app





## [2.11.29](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.28...netlify-cms-app@2.11.29) (2020-03-13)

**Note:** Version bump only for package netlify-cms-app





## [2.11.28](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.27...netlify-cms-app@2.11.28) (2020-03-12)

**Note:** Version bump only for package netlify-cms-app





## [2.11.27](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.26...netlify-cms-app@2.11.27) (2020-03-03)

**Note:** Version bump only for package netlify-cms-app





## [2.11.26](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.25...netlify-cms-app@2.11.26) (2020-02-27)

**Note:** Version bump only for package netlify-cms-app





## [2.11.25](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.24...netlify-cms-app@2.11.25) (2020-02-25)

**Note:** Version bump only for package netlify-cms-app





## [2.11.24](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.23...netlify-cms-app@2.11.24) (2020-02-25)

**Note:** Version bump only for package netlify-cms-app





## [2.11.23](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.22...netlify-cms-app@2.11.23) (2020-02-22)

**Note:** Version bump only for package netlify-cms-app





## [2.11.22](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.21...netlify-cms-app@2.11.22) (2020-02-22)

**Note:** Version bump only for package netlify-cms-app





## [2.11.21](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.20...netlify-cms-app@2.11.21) (2020-02-19)

**Note:** Version bump only for package netlify-cms-app





## [2.11.20](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.19...netlify-cms-app@2.11.20) (2020-02-17)

**Note:** Version bump only for package netlify-cms-app





## [2.11.19](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.18...netlify-cms-app@2.11.19) (2020-02-14)

**Note:** Version bump only for package netlify-cms-app





## [2.11.18](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.17...netlify-cms-app@2.11.18) (2020-02-13)

**Note:** Version bump only for package netlify-cms-app





## [2.11.17](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.16...netlify-cms-app@2.11.17) (2020-02-12)

**Note:** Version bump only for package netlify-cms-app





## [2.11.16](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.15...netlify-cms-app@2.11.16) (2020-02-11)

**Note:** Version bump only for package netlify-cms-app





## [2.11.15](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.14...netlify-cms-app@2.11.15) (2020-02-10)


### Reverts

* Revert "chore(release): publish" ([a015d1d](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/a015d1d92a4b1c0130c44fcef1c9ecdb157a0f07))





## [2.11.14](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.13...netlify-cms-app@2.11.14) (2020-02-06)

**Note:** Version bump only for package netlify-cms-app





## [2.11.13](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.12...netlify-cms-app@2.11.13) (2020-02-01)

**Note:** Version bump only for package netlify-cms-app





## [2.11.12](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.11...netlify-cms-app@2.11.12) (2020-01-30)

**Note:** Version bump only for package netlify-cms-app





## [2.11.11](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.10...netlify-cms-app@2.11.11) (2020-01-29)

**Note:** Version bump only for package netlify-cms-app





## [2.11.10](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.9...netlify-cms-app@2.11.10) (2020-01-26)

**Note:** Version bump only for package netlify-cms-app





## [2.11.9](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.8...netlify-cms-app@2.11.9) (2020-01-24)

**Note:** Version bump only for package netlify-cms-app





## [2.11.8](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.7...netlify-cms-app@2.11.8) (2020-01-23)

**Note:** Version bump only for package netlify-cms-app





## [2.11.7](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.6...netlify-cms-app@2.11.7) (2020-01-22)

**Note:** Version bump only for package netlify-cms-app





## [2.11.6](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.5...netlify-cms-app@2.11.6) (2020-01-21)

**Note:** Version bump only for package netlify-cms-app





## [2.11.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.4...netlify-cms-app@2.11.5) (2020-01-16)

**Note:** Version bump only for package netlify-cms-app





## [2.11.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.3...netlify-cms-app@2.11.4) (2020-01-15)

**Note:** Version bump only for package netlify-cms-app





## [2.11.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.2...netlify-cms-app@2.11.3) (2020-01-14)

**Note:** Version bump only for package netlify-cms-app





## [2.11.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.1...netlify-cms-app@2.11.2) (2020-01-14)

**Note:** Version bump only for package netlify-cms-app





## [2.11.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.0...netlify-cms-app@2.11.1) (2020-01-09)

**Note:** Version bump only for package netlify-cms-app





# [2.11.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.0-beta.1...netlify-cms-app@2.11.0) (2020-01-07)


### Bug Fixes

* move code widget and locales to netlify-cms-app ([#3025](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/3025)) ([74ecc21](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/74ecc21879e984e0104e5bb81c30f661162f6758))





# [2.11.0-beta.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.11.0-beta.0...netlify-cms-app@2.11.0-beta.1) (2019-12-19)

**Note:** Version bump only for package netlify-cms-app





# [2.11.0-beta.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0...netlify-cms-app@2.11.0-beta.0) (2019-12-18)


### Features

* bundle assets with content ([#2958](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2958)) ([2b41d8a](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/2b41d8a838a9c8a6b21cde2ddd16b9288334e298))





# [2.10.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0-beta.5...netlify-cms-app@2.10.0) (2019-12-18)

**Note:** Version bump only for package netlify-cms-app





# [2.10.0-beta.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0-beta.4...netlify-cms-app@2.10.0-beta.5) (2019-12-16)


### Features

* Code Widget + Markdown Widget Internal Overhaul ([#2828](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2828)) ([18c579d](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/18c579d0e9f0ff71ed8c52f5c66f2309259af054))





# [2.10.0-beta.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0-beta.3...netlify-cms-app@2.10.0-beta.4) (2019-12-11)

**Note:** Version bump only for package netlify-cms-app





# [2.10.0-beta.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0-beta.2...netlify-cms-app@2.10.0-beta.3) (2019-12-02)


### Bug Fixes

* .d.ts definitions for core and app ([#2929](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2929)) ([7391061](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/7391061b3b8b1971b994f497a6df29b7d5c3da74))





# [2.10.0-beta.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0-beta.1...netlify-cms-app@2.10.0-beta.2) (2019-11-26)

**Note:** Version bump only for package netlify-cms-app





# [2.10.0-beta.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.10.0-beta.0...netlify-cms-app@2.10.0-beta.1) (2019-11-18)

**Note:** Version bump only for package netlify-cms-app





# [2.10.0-beta.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.8-beta.5...netlify-cms-app@2.10.0-beta.0) (2019-11-18)


### Features

* add translation support ([#2870](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2870)) ([096b067](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/096b067d4542c723630ded631fc9a4ba950732f3)), closes [#2877](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2877)





## [2.9.8-beta.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.8-beta.4...netlify-cms-app@2.9.8-beta.5) (2019-11-07)

**Note:** Version bump only for package netlify-cms-app





## [2.9.8-beta.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.8-beta.3...netlify-cms-app@2.9.8-beta.4) (2019-09-26)

**Note:** Version bump only for package netlify-cms-app





## [2.9.8-beta.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.8-beta.2...netlify-cms-app@2.9.8-beta.3) (2019-09-04)

**Note:** Version bump only for package netlify-cms-app





## [2.9.8-beta.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.8-beta.1...netlify-cms-app@2.9.8-beta.2) (2019-08-24)

**Note:** Version bump only for package netlify-cms-app





## [2.9.8-beta.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.8-beta.0...netlify-cms-app@2.9.8-beta.1) (2019-08-24)

**Note:** Version bump only for package netlify-cms-app





## [2.9.8-beta.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.7...netlify-cms-app@2.9.8-beta.0) (2019-07-24)

**Note:** Version bump only for package netlify-cms-app





## [2.9.7](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.6...netlify-cms-app@2.9.7) (2019-07-24)

**Note:** Version bump only for package netlify-cms-app





## [2.9.6](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.5...netlify-cms-app@2.9.6) (2019-07-11)

**Note:** Version bump only for package netlify-cms-app





## [2.9.5](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.4...netlify-cms-app@2.9.5) (2019-06-28)

**Note:** Version bump only for package netlify-cms-app





## [2.9.4](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.3...netlify-cms-app@2.9.4) (2019-06-26)

**Note:** Version bump only for package netlify-cms-app





## [2.9.3](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.2...netlify-cms-app@2.9.3) (2019-06-18)

**Note:** Version bump only for package netlify-cms-app





## [2.9.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.2-beta.2...netlify-cms-app@2.9.2) (2019-06-14)

**Note:** Version bump only for package netlify-cms-app





## [2.9.2-beta.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.2-beta.1...netlify-cms-app@2.9.2-beta.2) (2019-06-14)

**Note:** Version bump only for package netlify-cms-app





## [2.9.2-beta.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.2-beta.0...netlify-cms-app@2.9.2-beta.1) (2019-05-15)

**Note:** Version bump only for package netlify-cms-app





## [2.9.2-beta.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.1...netlify-cms-app@2.9.2-beta.0) (2019-04-10)

**Note:** Version bump only for package netlify-cms-app





## [2.9.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.1-beta.2...netlify-cms-app@2.9.1) (2019-04-10)

**Note:** Version bump only for package netlify-cms-app





## [2.9.1-beta.2](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.1-beta.1...netlify-cms-app@2.9.1-beta.2) (2019-04-05)

**Note:** Version bump only for package netlify-cms-app





## [2.9.1-beta.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.1-beta.0...netlify-cms-app@2.9.1-beta.1) (2019-04-02)

**Note:** Version bump only for package netlify-cms-app





## [2.9.1-beta.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.0...netlify-cms-app@2.9.1-beta.0) (2019-03-29)

**Note:** Version bump only for package netlify-cms-app





# [2.9.0](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.0-beta.1...netlify-cms-app@2.9.0) (2019-03-29)

**Note:** Version bump only for package netlify-cms-app





# [2.9.0-beta.1](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/compare/netlify-cms-app@2.9.0-beta.0...netlify-cms-app@2.9.0-beta.1) (2019-03-29)


### Bug Fixes

* **netlify-cms-app:** add missing dependencies([#2255](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2255)) ([cf03a37](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/cf03a37))





# 2.9.0-beta.0 (2019-03-28)


### Features

* add byo react package netlify-cms-app ([#2252](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/issues/2252)) ([ff4ffd7](https://github.com/netlify/netlify-cms/tree/master/packages/netlify-cms-app/commit/ff4ffd7))
