export const COMMIT_AUTHOR = 'commit_author';
export const COMMIT_DATE = 'commit_date';
